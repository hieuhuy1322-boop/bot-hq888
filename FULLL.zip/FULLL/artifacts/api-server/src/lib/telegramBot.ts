import { startBot as startBotImpl } from "../bot";
import { getBotInstance } from "./bot-instance";
import { logger } from "./logger";

let botRunning = false;

export function isBotRunning(): boolean {
  return botRunning;
}

export async function startBot(): Promise<void> {
  if (botRunning) return;
  const b = startBotImpl();
  if (b) {
    botRunning = true;
    logger.info("Bot thực (HQ88.FUN) đã khởi động");
  }
}

export async function stopBot(): Promise<void> {
  if (!botRunning) return;
  const b = getBotInstance();
  if (b) {
    try {
      await b.stopPolling();
    } catch (err) {
      logger.error({ err }, "Lỗi khi dừng bot polling");
    }
  }
  botRunning = false;
  logger.info("Bot đã dừng");
}

export function getBot() {
  return getBotInstance();
}
