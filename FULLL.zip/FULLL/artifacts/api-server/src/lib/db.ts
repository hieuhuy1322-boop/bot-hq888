import Database from "better-sqlite3";
import path from "path";
import { mkdirSync } from "fs";

const DATA_DIR = path.resolve(process.cwd(), "data");
mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = process.env["BOT_DB_PATH"] ?? path.join(DATA_DIR, "bot.db");

export const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
