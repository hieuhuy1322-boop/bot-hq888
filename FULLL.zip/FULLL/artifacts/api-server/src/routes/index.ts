import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { gameSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { startBot, stopBot, isBotRunning } from "../lib/telegramBot";
import healthRouter from "./health";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/admin", adminRouter);

// Public bot-status endpoint — no auth, for bots to check
router.get("/admin/bot-status/public", async (_req, res) => {
  try {
    const rows = await db.select().from(gameSettingsTable).where(eq(gameSettingsTable.key, "bot_enabled")).limit(1);
    const enabled = rows[0]?.value !== "false";
    res.json({ enabled });
  } catch {
    res.json({ enabled: true });
  }
});

// ── Public bot control routes (mirrors original server.js) ──

router.get("/bot/start", async (_req, res) => {
  try {
    await startBot();
    res.json({ ok: true, status: "started" });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

router.get("/bot/stop", async (_req, res) => {
  try {
    await stopBot();
    res.json({ ok: true, status: "stopped" });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

router.get("/bot/status", (_req, res) => {
  res.json({ running: isBotRunning() });
});

export default router;
