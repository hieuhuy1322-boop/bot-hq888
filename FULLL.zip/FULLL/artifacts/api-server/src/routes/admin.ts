import { Router, type IRouter } from "express";
import { startBot, stopBot, isBotRunning } from "../lib/telegramBot";
import { adminForceDice } from "../bot";
import { getBotInstance } from "../lib/bot-instance";
import { db as pgDb } from "@workspace/db";
import { adminUsersTable } from "@workspace/db";
import { db as sqliteDb } from "../lib/db";
import { eq } from "drizzle-orm";
import crypto from "crypto";

const router: IRouter = Router();

// ── Helpers ────────────────────────────────────────
function hashPw(pw: string): string {
  return crypto.createHash("sha256").update(pw + "hq88salt").digest("hex");
}

function makeToken(username: string): string {
  const payload = Buffer.from(JSON.stringify({ username, ts: Date.now() })).toString("base64");
  const sig = crypto.createHmac("sha256", process.env.SESSION_SECRET || "hq88secret").update(payload).digest("hex");
  return `${payload}.${sig}`;
}

function verifyToken(token: string): string | null {
  try {
    const [payload, sig] = token.split(".");
    if (!payload || !sig) return null;
    const expected = crypto.createHmac("sha256", process.env.SESSION_SECRET || "hq88secret").update(payload).digest("hex");
    if (sig !== expected) return null;
    const data = JSON.parse(Buffer.from(payload, "base64").toString());
    if (Date.now() - data.ts > 3600_000) return null;
    return data.username;
  } catch { return null; }
}

// SQLite helpers
function sqliteGet(sql: string, ...params: any[]): any {
  return sqliteDb.prepare(sql).get(...params);
}
function sqliteAll(sql: string, ...params: any[]): any[] {
  return sqliteDb.prepare(sql).all(...params) as any[];
}
function sqliteRun(sql: string, ...params: any[]) {
  return sqliteDb.prepare(sql).run(...params);
}

function getBotSetting(key: string, def = ""): string {
  const row = sqliteGet("SELECT value FROM bot_settings WHERE key=?", key);
  return row?.value ?? def;
}
function setBotSetting(key: string, value: string) {
  sqliteRun("INSERT OR REPLACE INTO bot_settings (key, value) VALUES (?,?)", key, value);
}

function todayStr() { return new Date().toISOString().slice(0, 10); }

async function ensureAdmin(): Promise<void> {
  const existing = await pgDb.select().from(adminUsersTable).limit(1);
  if (!existing.length) {
    await pgDb.insert(adminUsersTable).values({ username: "admin", password_hash: hashPw("admin123") });
  }
}

// ── Auth middleware ─────────────────────────────────
function authMiddleware(req: any, res: any, next: any) {
  const auth = req.headers["authorization"] || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  const username = verifyToken(token);
  if (!username) { res.status(401).json({ ok: false, error: "Unauthorized" }); return; }
  req.adminUsername = username;
  next();
}

// ── POST /admin/auth ────────────────────────────────
router.post("/auth", async (req, res) => {
  await ensureAdmin();
  const { username, password } = req.body || {};
  if (!username || !password) { res.json({ ok: false, error: "Missing credentials" }); return; }
  const rows = await pgDb.select().from(adminUsersTable).where(eq(adminUsersTable.username, username)).limit(1);
  const admin = rows[0];
  if (!admin || admin.password_hash !== hashPw(password)) { res.json({ ok: false, error: "Invalid credentials" }); return; }
  res.json({ ok: true, token: makeToken(username) });
});

// All routes below require auth
router.use(authMiddleware);

// ── GET /admin/stats ───────────────────────────────
router.get("/stats", (_req, res) => {
  const today = todayStr();

  const totalUsers    = (sqliteGet("SELECT COUNT(*) as c FROM users WHERE is_fake_bot=0 OR is_fake_bot IS NULL"))?.c ?? 0;
  const blockedUsers  = (sqliteGet("SELECT COUNT(*) as c FROM users WHERE is_blocked=1 AND (is_fake_bot=0 OR is_fake_bot IS NULL)"))?.c ?? 0;
  const todaySessions = (sqliteGet("SELECT COUNT(*) as c FROM game_sessions WHERE date(created_at)=?", today))?.c ?? 0;
  const todayBets     = (sqliteGet("SELECT COALESCE(SUM(amount),0) as s FROM game_bets gb JOIN game_sessions gs ON gb.session_id=gs.id WHERE date(gs.created_at)=?", today))?.s ?? 0;
  const todayWin      = (sqliteGet("SELECT COALESCE(SUM(payout),0) as s FROM game_bets gb JOIN game_sessions gs ON gb.session_id=gs.id WHERE gb.is_win=1 AND date(gs.created_at)=?", today))?.s ?? 0;
  const todayDeposit  = (sqliteGet("SELECT COALESCE(SUM(amount),0) as s FROM pending_deposits WHERE status='approved' AND date(created_at)=?", today))?.s ?? 0;
  const todayWithdraw = (sqliteGet("SELECT COALESCE(SUM(net),0) as s FROM pending_withdrawals WHERE status='approved' AND date(created_at)=?", today))?.s ?? 0;
  const pendingDeps   = (sqliteGet("SELECT COUNT(*) as c FROM pending_deposits WHERE status='pending'"))?.c ?? 0;
  const pendingWits   = (sqliteGet("SELECT COUNT(*) as c FROM pending_withdrawals WHERE status='pending'"))?.c ?? 0;
  const totalDeposit  = (sqliteGet("SELECT COALESCE(SUM(amount),0) as s FROM pending_deposits WHERE status='approved'"))?.s ?? 0;
  const totalWithdraw = (sqliteGet("SELECT COALESCE(SUM(net),0) as s FROM pending_withdrawals WHERE status='approved'"))?.s ?? 0;
  const totalBets     = (sqliteGet("SELECT COALESCE(SUM(amount),0) as s FROM game_bets"))?.s ?? 0;

  const recentWithdrawals = sqliteAll(`
    SELECT w.id, w.amount, w.net, w.bank_name, w.bank_account, w.created_at,
           u.first_name, u.telegram_id
    FROM pending_withdrawals w LEFT JOIN users u ON w.user_id=u.id
    WHERE w.status='pending' ORDER BY w.created_at DESC LIMIT 10
  `);

  res.json({
    totalUsers: Number(totalUsers),
    blockedUsers: Number(blockedUsers),
    todaySessions: Number(todaySessions),
    todayBets: Number(todayBets),
    todayWin: Number(todayWin),
    todayDeposit: Number(todayDeposit),
    todayWithdraw: Number(todayWithdraw),
    pendingDeposits: Number(pendingDeps),
    pendingWithdrawals: Number(pendingWits),
    totalDeposit: Number(totalDeposit),
    totalWithdraw: Number(totalWithdraw),
    totalBetAllTime: Number(totalBets),
    recentWithdrawals,
  });
});

// ── GET /admin/live ────────────────────────────────
router.get("/live", (req, res) => {
  const chatId = req.query["chat_id"] ? Number(req.query["chat_id"]) : null;

  const chatGroups = sqliteAll(`
    SELECT chat_id, COUNT(*) as total_bets FROM game_sessions GROUP BY chat_id
  `);

  const activeChatId = chatId ?? chatGroups[0]?.chat_id ?? null;

  const currentSession = activeChatId
    ? sqliteGet("SELECT * FROM game_sessions WHERE chat_id=? AND status='betting' ORDER BY id DESC LIMIT 1", activeChatId)
    : null;
  const lastSession = activeChatId
    ? sqliteGet("SELECT * FROM game_sessions WHERE chat_id=? AND status='done' ORDER BY id DESC LIMIT 1", activeChatId)
    : null;

  function getSessionData(session: any) {
    if (!session) return null;
    const bets = sqliteAll(`
      SELECT b.id, b.bet_type, b.amount, b.is_win, b.payout, b.created_at,
             u.first_name, u.username
      FROM game_bets b LEFT JOIN users u ON b.user_id=u.id
      WHERE b.session_id=?
    `, session.id);
    const summary: Record<string, { total: number; count: number }> = {};
    let totalBet = 0;
    for (const b of bets) {
      if (!summary[b.bet_type]) summary[b.bet_type] = { total: 0, count: 0 };
      summary[b.bet_type]!.total += Number(b.amount);
      summary[b.bet_type]!.count += 1;
      totalBet += Number(b.amount);
    }
    return { session, bets, summary, totalBet };
  }

  res.json({
    chatGroups,
    current: getSessionData(currentSession),
    last: getSessionData(lastSession),
  });
});

// ── GET /admin/users ───────────────────────────────
router.get("/users", (req, res) => {
  const page   = Math.max(1, parseInt(req.query["page"] as string) || 1);
  const limit  = 20;
  const offset = (page - 1) * limit;
  const search  = ((req.query["search"] as string) || "").trim();
  const blocked = req.query["blocked"] as string | undefined;

  let where = "WHERE (is_fake_bot=0 OR is_fake_bot IS NULL)";
  const params: any[] = [];
  if (search) {
    where += " AND (first_name LIKE ? OR username LIKE ? OR CAST(telegram_id AS TEXT) LIKE ?)";
    const like = `%${search}%`;
    params.push(like, like, like);
  }
  if (blocked === "1") { where += " AND is_blocked=1"; }
  if (blocked === "0") { where += " AND is_blocked=0"; }

  const total = (sqliteGet(`SELECT COUNT(*) as c FROM users ${where}`, ...params))?.c ?? 0;
  const users = sqliteAll(`SELECT * FROM users ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`, ...params, limit, offset);

  res.json({ users, total: Number(total), totalPages: Math.max(1, Math.ceil(Number(total) / limit)) });
});

// ── GET /admin/users/:id ───────────────────────────
router.get("/users/:id", (req, res) => {
  const id = parseInt(req.params["id"]!);
  const user = sqliteGet("SELECT * FROM users WHERE id=?", id);
  if (!user) { res.status(404).json({ ok: false, error: "Not found" }); return; }
  res.json(user);
});

// ── GET /admin/users/:id/transactions ─────────────
router.get("/users/:id/transactions", (req, res) => {
  const id    = parseInt(req.params["id"]!);
  const limit = parseInt(req.query["limit"] as string) || 20;
  const transactions = sqliteAll(
    "SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT ?", id, limit
  );
  res.json({ transactions });
});

// ── POST /admin/users/:id/block ────────────────────
router.post("/users/:id/block", (req, res) => {
  sqliteRun("UPDATE users SET is_blocked=1 WHERE id=?", parseInt(req.params["id"]!));
  res.json({ ok: true });
});

// ── POST /admin/users/:id/unblock ─────────────────
router.post("/users/:id/unblock", (req, res) => {
  sqliteRun("UPDATE users SET is_blocked=0 WHERE id=?", parseInt(req.params["id"]!));
  res.json({ ok: true });
});

// ── POST /admin/users/:id/balance ─────────────────
router.post("/users/:id/balance", (req, res) => {
  const id    = parseInt(req.params["id"]!);
  const { amount, type } = req.body || {};
  if (!amount || Number(amount) <= 0) { res.json({ ok: false, error: "Invalid amount" }); return; }
  const user = sqliteGet("SELECT * FROM users WHERE id=?", id);
  if (!user) { res.json({ ok: false, error: "Not found" }); return; }
  const delta      = type === "add" ? Number(amount) : -Number(amount);
  const newBalance = Math.max(0, Number(user.balance) + delta);
  sqliteRun("UPDATE users SET balance=? WHERE id=?", newBalance, id);
  sqliteRun(
    "INSERT INTO transactions (user_id,type,amount,fee,balance_before,balance_after,note) VALUES (?,?,?,0,?,?,?)",
    id, type === "add" ? "admin_add" : "admin_sub", Number(amount), user.balance, newBalance,
    type === "add" ? "Admin cộng tiền" : "Admin trừ tiền"
  );
  res.json({ ok: true, balance: newBalance });
});

// ── POST /admin/users/:id/reset ───────────────────
router.post("/users/:id/reset", (req, res) => {
  sqliteRun(
    "UPDATE users SET balance=0, total_bet=0, total_deposit=0, total_withdraw=0, win_streak=0, lose_streak=0 WHERE id=?",
    parseInt(req.params["id"]!)
  );
  res.json({ ok: true });
});

// ── GET /admin/sessions ───────────────────────────
router.get("/sessions", (req, res) => {
  const page   = Math.max(1, parseInt(req.query["page"] as string) || 1);
  const limit  = 20;
  const offset = (page - 1) * limit;
  const total    = (sqliteGet("SELECT COUNT(*) as c FROM game_sessions"))?.c ?? 0;
  const sessions = sqliteAll("SELECT * FROM game_sessions ORDER BY id DESC LIMIT ? OFFSET ?", limit, offset);
  res.json({ sessions, total: Number(total), totalPages: Math.max(1, Math.ceil(Number(total) / limit)) });
});

// ── GET /admin/sessions/:id/bets ──────────────────
router.get("/sessions/:id/bets", (req, res) => {
  const id      = parseInt(req.params["id"]!);
  const session = sqliteGet("SELECT * FROM game_sessions WHERE id=?", id);
  const bets    = sqliteAll(`
    SELECT b.id, b.bet_type, b.amount, b.is_win, b.payout, b.created_at,
           u.first_name, u.username
    FROM game_bets b LEFT JOIN users u ON b.user_id=u.id
    WHERE b.session_id=? ORDER BY b.created_at DESC
  `, id);
  res.json({ session, bets });
});

// ── GET /admin/bets ───────────────────────────────
router.get("/bets", (req, res) => {
  const page   = Math.max(1, parseInt(req.query["page"] as string) || 1);
  const limit  = 20;
  const offset = (page - 1) * limit;
  const search  = ((req.query["search"] as string) || "").trim();

  let where = "";
  const params: any[] = [];
  if (search) {
    where = "WHERE u.first_name LIKE ? OR u.username LIKE ? OR CAST(u.telegram_id AS TEXT) LIKE ?";
    const like = `%${search}%`;
    params.push(like, like, like);
  }

  const total = (sqliteGet(`
    SELECT COUNT(*) as c FROM game_bets b LEFT JOIN users u ON b.user_id=u.id ${where}
  `, ...params))?.c ?? 0;

  const bets = sqliteAll(`
    SELECT b.id, b.bet_type, b.amount, b.is_win, b.payout, b.session_id, b.created_at,
           gs.session_number, u.first_name, u.username
    FROM game_bets b
    LEFT JOIN users u ON b.user_id=u.id
    LEFT JOIN game_sessions gs ON b.session_id=gs.id
    ${where} ORDER BY b.created_at DESC LIMIT ? OFFSET ?
  `, ...params, limit, offset);

  res.json({ bets, total: Number(total), totalPages: Math.max(1, Math.ceil(Number(total) / limit)) });
});

// ── GET /admin/deposits ───────────────────────────
router.get("/deposits", (req, res) => {
  const filter = (req.query["filter"] as string) || "pending";
  const where  = filter === "all" ? "" : "WHERE d.status=?";
  const params = filter === "all" ? [] : [filter];

  const deposits = sqliteAll(`
    SELECT d.id, d.amount, d.status, d.created_at, d.group_chat_id,
           u.first_name, u.telegram_id, u.id as user_id
    FROM pending_deposits d LEFT JOIN users u ON d.user_id=u.id
    ${where} ORDER BY d.created_at DESC LIMIT 100
  `, ...params);

  res.json({ deposits });
});

// ── POST /admin/deposits/:id/approve ─────────────
router.post("/deposits/:id/approve", (req, res) => {
  const id  = parseInt(req.params["id"]!);
  const dep = sqliteGet("SELECT * FROM pending_deposits WHERE id=?", id);
  if (!dep || dep.status !== "pending") { res.json({ ok: false, error: "Not found or already processed" }); return; }

  const user = sqliteGet("SELECT * FROM users WHERE id=?", dep.user_id);
  if (!user) { res.json({ ok: false, error: "User not found" }); return; }

  const now        = new Date().toISOString();
  const newBalance = Number(user.balance) + Number(dep.amount);
  const newTotalDep = Number(user.total_deposit) + Number(dep.amount);

  sqliteDb.transaction(() => {
    sqliteRun("UPDATE pending_deposits SET status='approved', handled_at=? WHERE id=?", now, id);
    sqliteRun("UPDATE users SET balance=?, total_deposit=? WHERE id=?", newBalance, newTotalDep, dep.user_id);
    sqliteRun(
      "INSERT INTO transactions (user_id,type,amount,fee,balance_before,balance_after,note) VALUES (?,?,?,0,?,?,?)",
      dep.user_id, "deposit", dep.amount, user.balance, newBalance, "Nạp tiền được duyệt"
    );
  })();

  // Notify user via bot
  try {
    const bot = getBotInstance();
    if (bot) {
      bot.sendMessage(user.telegram_id,
        `✅ Nạp tiền thành công!\n💰 Số tiền: *${Number(dep.amount).toLocaleString("vi-VN")}*\n💳 Số dư mới: *${newBalance.toLocaleString("vi-VN")}*`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
    }
  } catch {}

  res.json({ ok: true });
});

// ── POST /admin/deposits/:id/reject ──────────────
router.post("/deposits/:id/reject", (req, res) => {
  const id  = parseInt(req.params["id"]!);
  const dep = sqliteGet("SELECT * FROM pending_deposits WHERE id=? AND status='pending'", id);
  if (!dep) { res.json({ ok: false, error: "Not found or already processed" }); return; }

  sqliteRun("UPDATE pending_deposits SET status='rejected', handled_at=? WHERE id=?", new Date().toISOString(), id);

  try {
    const bot = getBotInstance();
    const user = sqliteGet("SELECT * FROM users WHERE id=?", dep.user_id);
    if (bot && user) {
      bot.sendMessage(user.telegram_id,
        `❌ Yêu cầu nạp tiền *${Number(dep.amount).toLocaleString("vi-VN")}* đã bị từ chối.\nLiên hệ hỗ trợ nếu có thắc mắc.`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
    }
  } catch {}

  res.json({ ok: true });
});

// ── GET /admin/withdrawals ────────────────────────
router.get("/withdrawals", (req, res) => {
  const filter = (req.query["filter"] as string) || "pending";
  const where  = filter === "all" ? "" : "WHERE w.status=?";
  const params = filter === "all" ? [] : [filter];

  const withdrawals = sqliteAll(`
    SELECT w.id, w.amount, w.fee, w.net, w.status, w.bank_name, w.bank_account, w.bank_owner,
           w.created_at, u.first_name, u.telegram_id, u.id as user_id
    FROM pending_withdrawals w LEFT JOIN users u ON w.user_id=u.id
    ${where} ORDER BY w.created_at DESC LIMIT 100
  `, ...params);

  res.json({ withdrawals });
});

// ── POST /admin/withdrawals/:id/approve ───────────
router.post("/withdrawals/:id/approve", (req, res) => {
  const id  = parseInt(req.params["id"]!);
  const wit = sqliteGet("SELECT * FROM pending_withdrawals WHERE id=?", id);
  if (!wit || wit.status !== "pending") { res.json({ ok: false, error: "Not found or already processed" }); return; }

  const now  = new Date().toISOString();
  sqliteRun("UPDATE pending_withdrawals SET status='approved', handled_at=? WHERE id=?", now, id);
  const user = sqliteGet("SELECT * FROM users WHERE id=?", wit.user_id);
  if (user) {
    const newTotalWithdraw = Number(user.total_withdraw) + Number(wit.net || wit.amount);
    sqliteRun("UPDATE users SET total_withdraw=? WHERE id=?", newTotalWithdraw, wit.user_id);
    sqliteRun(
      "INSERT INTO transactions (user_id,type,amount,fee,balance_before,balance_after,note) VALUES (?,?,?,?,?,?,?)",
      wit.user_id, "withdraw", wit.amount, wit.fee || 0, user.balance, user.balance, "Rút tiền được duyệt"
    );
    try {
      const bot = getBotInstance();
      if (bot) {
        bot.sendMessage(user.telegram_id,
          `✅ Rút tiền thành công!\n💸 Đã chuyển *${Number(wit.net || wit.amount).toLocaleString("vi-VN")}* về tài khoản của bạn.\n🏦 ${wit.bank_name || ""} - ${wit.bank_account || ""}`,
          { parse_mode: "Markdown" }
        ).catch(() => {});
      }
    } catch {}
  }
  res.json({ ok: true });
});

// ── POST /admin/withdrawals/:id/reject ────────────
router.post("/withdrawals/:id/reject", (req, res) => {
  const id  = parseInt(req.params["id"]!);
  const wit = sqliteGet("SELECT * FROM pending_withdrawals WHERE id=? AND status='pending'", id);
  if (!wit) { res.json({ ok: false, error: "Not found or already processed" }); return; }

  const now  = new Date().toISOString();
  const user = sqliteGet("SELECT * FROM users WHERE id=?", wit.user_id);

  sqliteDb.transaction(() => {
    sqliteRun("UPDATE pending_withdrawals SET status='rejected', handled_at=? WHERE id=?", now, id);
    if (user) {
      const newBalance = Number(user.balance) + Number(wit.amount);
      sqliteRun("UPDATE users SET balance=? WHERE id=?", newBalance, wit.user_id);
      sqliteRun(
        "INSERT INTO transactions (user_id,type,amount,fee,balance_before,balance_after,note) VALUES (?,?,?,0,?,?,?)",
        wit.user_id, "withdraw_reject", wit.amount, user.balance, newBalance, "Rút tiền bị từ chối - hoàn tiền"
      );
    }
  })();

  try {
    const bot = getBotInstance();
    if (bot && user) {
      bot.sendMessage(user.telegram_id,
        `❌ Yêu cầu rút tiền *${Number(wit.amount).toLocaleString("vi-VN")}* đã bị từ chối.\n💰 Tiền đã được hoàn lại vào ví.`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
    }
  } catch {}

  res.json({ ok: true });
});

// ── GET /admin/giftcodes ──────────────────────────
router.get("/giftcodes", (_req, res) => {
  const giftcodes = sqliteAll("SELECT * FROM giftcodes ORDER BY created_at DESC");
  res.json({ giftcodes });
});

// ── POST /admin/giftcodes ─────────────────────────
router.post("/giftcodes", (req, res) => {
  const { code, amount, max_uses } = req.body || {};
  if (!code || !amount) { res.json({ ok: false, error: "Missing fields" }); return; }
  try {
    sqliteRun(
      "INSERT INTO giftcodes (code, amount, max_uses) VALUES (?,?,?)",
      String(code).toUpperCase(), Number(amount), Number(max_uses) || 1
    );
    res.json({ ok: true });
  } catch {
    res.json({ ok: false, error: "Code already exists" });
  }
});

// ── DELETE /admin/giftcodes/:code ─────────────────
router.delete("/giftcodes/:code", (req, res) => {
  sqliteRun("UPDATE giftcodes SET is_active=0 WHERE code=?", req.params["code"]!);
  res.json({ ok: true });
});

// ── POST /admin/broadcast ─────────────────────────
router.post("/broadcast", async (req, res) => {
  const { message } = req.body || {};
  if (!message) { res.json({ ok: false, error: "Missing message" }); return; }

  const bot = getBotInstance();
  if (!bot) { res.json({ ok: false, error: "Bot chưa được bật" }); return; }

  const users = sqliteAll("SELECT telegram_id FROM users WHERE is_blocked=0 AND (is_fake_bot=0 OR is_fake_bot IS NULL)");
  let sent = 0, failed = 0;

  for (const u of users) {
    try {
      await bot.sendMessage(u.telegram_id,
        `📣 *THÔNG BÁO TỪ HỆ THỐNG*\n\n${message}`,
        { parse_mode: "Markdown" }
      );
      sent++;
    } catch { failed++; }
    await new Promise(r => setTimeout(r, 50));
  }

  res.json({ ok: true, sent, failed });
});

// ── GET /admin/fake-bots ──────────────────────────
router.get("/fake-bots", (_req, res) => {
  const bots = sqliteAll("SELECT * FROM fake_bots ORDER BY id");
  res.json({ bots });
});

// ── POST /admin/fake-bots ─────────────────────────
router.post("/fake-bots", (req, res) => {
  const { name, min_bet, max_bet, bet_types, delay_min, delay_max, balance_refill, vip_icon } = req.body || {};
  if (!name) { res.json({ ok: false, error: "Missing name" }); return; }

  // Create user record for the fake bot
  const telegramId = -(Date.now() % 1_000_000_000);
  sqliteRun(
    "INSERT OR IGNORE INTO users (telegram_id, first_name, balance, is_fake_bot) VALUES (?,?,50000000,1)",
    telegramId, name
  );
  const result = sqliteRun(
    "INSERT INTO fake_bots (name, telegram_id, min_bet, max_bet, bet_types, delay_min, delay_max, balance_refill, vip_icon) VALUES (?,?,?,?,?,?,?,?,?)",
    name, telegramId, Number(min_bet) || 10000, Number(max_bet) || 500000,
    bet_types || "tai,xiu", Number(delay_min) || 5, Number(delay_max) || 35,
    Number(balance_refill) || 50000000, vip_icon || "🏵️"
  );
  const bot = sqliteGet("SELECT * FROM fake_bots WHERE rowid=?", (result as any).lastInsertRowid);
  res.json({ ok: true, bot });
});

// ── PATCH /admin/fake-bots/:id ────────────────────
router.patch("/fake-bots/:id", (req, res) => {
  const id = parseInt(req.params["id"]!);
  const { name, min_bet, max_bet, bet_types, delay_min, delay_max, balance_refill, vip_icon } = req.body || {};
  sqliteRun(
    "UPDATE fake_bots SET name=COALESCE(?,name), min_bet=COALESCE(?,min_bet), max_bet=COALESCE(?,max_bet), bet_types=COALESCE(?,bet_types), delay_min=COALESCE(?,delay_min), delay_max=COALESCE(?,delay_max), balance_refill=COALESCE(?,balance_refill), vip_icon=COALESCE(?,vip_icon) WHERE id=?",
    name, min_bet ? Number(min_bet) : null, max_bet ? Number(max_bet) : null, bet_types,
    delay_min ? Number(delay_min) : null, delay_max ? Number(delay_max) : null,
    balance_refill ? Number(balance_refill) : null, vip_icon, id
  );
  res.json({ ok: true });
});

// ── POST /admin/fake-bots/:id/toggle ─────────────
router.post("/fake-bots/:id/toggle", (req, res) => {
  const id  = parseInt(req.params["id"]!);
  const bot = sqliteGet("SELECT * FROM fake_bots WHERE id=?", id);
  if (!bot) { res.json({ ok: false, error: "Not found" }); return; }
  const newVal = bot.enabled ? 0 : 1;
  sqliteRun("UPDATE fake_bots SET enabled=? WHERE id=?", newVal, id);
  res.json({ ok: true, is_active: newVal === 1 });
});

// ── GET /admin/game-control ───────────────────────
router.get("/game-control", (_req, res) => {
  const keys = ["force_taixiu", "force_td", "force_br", "force_sl", "force_xx"];
  const result: Record<string, string> = {};
  for (const key of keys) result[key] = "random";
  const rows = sqliteAll("SELECT key, value FROM bot_settings WHERE key IN (?,?,?,?,?)", ...keys);
  for (const row of rows) result[row.key] = row.value;
  res.json(result);
});

// ── POST /admin/game-control ──────────────────────
router.post("/game-control", (req, res) => {
  const keys = ["force_taixiu", "force_td", "force_br", "force_sl", "force_xx"];
  const body = req.body || {};
  for (const key of keys) {
    if (key in body) setBotSetting(key, String(body[key]));
  }

  // Also apply force_taixiu to active sessions via pendingForceDice
  if ("force_taixiu" in body && body["force_taixiu"] !== "random") {
    const val = String(body["force_taixiu"]);
    // val = "tai" | "xiu" | "chan" | "le" — map to dice combos
    const presets: Record<string, [number, number, number]> = {
      tai:  [4, 4, 4], xiu:  [1, 1, 2],
      chan: [2, 2, 4], le:   [1, 2, 4],
    };
    const dice = presets[val];
    if (dice) {
      // Apply to all active chats
      const sessions = sqliteAll("SELECT DISTINCT chat_id FROM game_sessions WHERE status='betting'");
      for (const s of sessions) {
        adminForceDice(s.chat_id, dice[0], dice[1], dice[2]);
      }
    }
  }

  res.json({ ok: true });
});

// ── POST /admin/game-control/reset ────────────────
router.post("/game-control/reset", (req, res) => {
  const keys = ["force_taixiu", "force_td", "force_br", "force_sl", "force_xx"];
  for (const key of keys) setBotSetting(key, "random");
  res.json({ ok: true });
});

// ── GET /admin/bot-status ─────────────────────────
router.get("/bot-status", (_req, res) => {
  const enabled = getBotSetting("bot_enabled", "true");
  res.json({ enabled: enabled !== "false", running: isBotRunning() });
});

// ── POST /admin/bot-toggle ────────────────────────
router.post("/bot-toggle", async (_req, res) => {
  const current = getBotSetting("bot_enabled", "true");
  const newVal  = current === "false" ? "true" : "false";
  setBotSetting("bot_enabled", newVal);
  if (newVal === "true" && !isBotRunning()) await startBot();
  if (newVal === "false" && isBotRunning())  await stopBot();
  res.json({ ok: true, enabled: newVal === "true", running: isBotRunning() });
});

// ── POST /admin/bot/start ─────────────────────────
router.post("/bot/start", async (_req, res) => {
  try {
    await startBot();
    setBotSetting("bot_enabled", "true");
    res.json({ ok: true, running: isBotRunning() });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message || "Không thể bật bot" });
  }
});

// ── POST /admin/bot/stop ──────────────────────────
router.post("/bot/stop", async (_req, res) => {
  try {
    await stopBot();
    setBotSetting("bot_enabled", "false");
    res.json({ ok: true, running: isBotRunning() });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message || "Không thể tắt bot" });
  }
});

// ── GET /admin/admin-info ─────────────────────────
router.get("/admin-info", (req, res) => {
  res.json({ username: (req as any).adminUsername });
});

// ── POST /admin/admin-settings ────────────────────
router.post("/admin-settings", async (req, res) => {
  const { new_username, current_password, new_password } = req.body || {};
  const username = (req as any).adminUsername;
  const rows  = await pgDb.select().from(adminUsersTable).where(eq(adminUsersTable.username, username)).limit(1);
  const admin = rows[0];
  if (!admin) { res.json({ ok: false, error: "Admin not found" }); return; }
  if (admin.password_hash !== hashPw(current_password || "")) { res.json({ ok: false, error: "Sai mật khẩu hiện tại" }); return; }
  const updates: any = { updated_at: new Date() };
  if (new_username) updates.username = new_username;
  if (new_password) updates.password_hash = hashPw(new_password);
  await pgDb.update(adminUsersTable).set(updates).where(eq(adminUsersTable.id, admin.id));
  res.json({ ok: true, token: makeToken(new_username || username) });
});

export default router;
