import { pgTable, text, serial, integer, bigint, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const adminUsersTable = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password_hash: text("password_hash").notNull(),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updated_at: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAdminUserSchema = createInsertSchema(adminUsersTable).omit({ id: true, created_at: true, updated_at: true });
export type InsertAdminUser = z.infer<typeof insertAdminUserSchema>;
export type AdminUser = typeof adminUsersTable.$inferSelect;

export const tgUsersTable = pgTable("tg_users", {
  id: serial("id").primaryKey(),
  telegram_id: text("telegram_id").notNull().unique(),
  username: text("username"),
  first_name: text("first_name"),
  balance: bigint("balance", { mode: "number" }).notNull().default(0),
  total_bet: bigint("total_bet", { mode: "number" }).notNull().default(0),
  total_deposit: bigint("total_deposit", { mode: "number" }).notNull().default(0),
  total_withdraw: bigint("total_withdraw", { mode: "number" }).notNull().default(0),
  total_win: bigint("total_win", { mode: "number" }).notNull().default(0),
  vip_level: integer("vip_level").notNull().default(0),
  is_blocked: boolean("is_blocked").notNull().default(false),
  win_streak: integer("win_streak").notNull().default(0),
  lose_streak: integer("lose_streak").notNull().default(0),
  bank_name: text("bank_name"),
  bank_account: text("bank_account"),
  chat_id: text("chat_id"),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updated_at: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTgUserSchema = createInsertSchema(tgUsersTable).omit({ id: true, created_at: true, updated_at: true });
export type InsertTgUser = z.infer<typeof insertTgUserSchema>;
export type TgUser = typeof tgUsersTable.$inferSelect;

export const gameSessionsTable = pgTable("game_sessions", {
  id: serial("id").primaryKey(),
  session_number: integer("session_number").notNull(),
  chat_id: text("chat_id").notNull(),
  status: text("status").notNull().default("betting"),
  dice1: integer("dice1"),
  dice2: integer("dice2"),
  dice3: integer("dice3"),
  total: integer("total"),
  result_tai: boolean("result_tai"),
  result_chan: boolean("result_chan"),
  is_triple: boolean("is_triple").notNull().default(false),
  total_bet: bigint("total_bet", { mode: "number" }).notNull().default(0),
  bet_count: integer("bet_count").notNull().default(0),
  force_result: text("force_result"),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  ended_at: timestamp("ended_at", { withTimezone: true }),
});

export const insertGameSessionSchema = createInsertSchema(gameSessionsTable).omit({ id: true, created_at: true });
export type InsertGameSession = z.infer<typeof insertGameSessionSchema>;
export type GameSession = typeof gameSessionsTable.$inferSelect;

export const betsTable = pgTable("bets", {
  id: serial("id").primaryKey(),
  session_id: integer("session_id").notNull(),
  user_id: integer("user_id").notNull(),
  bet_type: text("bet_type").notNull(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  is_win: boolean("is_win"),
  payout: bigint("payout", { mode: "number" }),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertBetSchema = createInsertSchema(betsTable).omit({ id: true, created_at: true });
export type InsertBet = z.infer<typeof insertBetSchema>;
export type Bet = typeof betsTable.$inferSelect;

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  type: text("type").notNull(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  note: text("note"),
  ref_id: integer("ref_id"),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactionsTable).omit({ id: true, created_at: true });
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactionsTable.$inferSelect;

export const depositsTable = pgTable("deposits", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  status: text("status").notNull().default("pending"),
  note: text("note"),
  proof_image: text("proof_image"),
  approved_at: timestamp("approved_at", { withTimezone: true }),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertDepositSchema = createInsertSchema(depositsTable).omit({ id: true, created_at: true });
export type InsertDeposit = z.infer<typeof insertDepositSchema>;
export type Deposit = typeof depositsTable.$inferSelect;

export const withdrawalsTable = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  status: text("status").notNull().default("pending"),
  bank_name: text("bank_name"),
  bank_account: text("bank_account"),
  note: text("note"),
  approved_at: timestamp("approved_at", { withTimezone: true }),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertWithdrawalSchema = createInsertSchema(withdrawalsTable).omit({ id: true, created_at: true });
export type InsertWithdrawal = z.infer<typeof insertWithdrawalSchema>;
export type Withdrawal = typeof withdrawalsTable.$inferSelect;

export const giftcodesTable = pgTable("giftcodes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  amount: bigint("amount", { mode: "number" }).notNull(),
  max_uses: integer("max_uses").notNull().default(1),
  used_count: integer("used_count").notNull().default(0),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertGiftcodeSchema = createInsertSchema(giftcodesTable).omit({ id: true, created_at: true, used_count: true });
export type InsertGiftcode = z.infer<typeof insertGiftcodeSchema>;
export type Giftcode = typeof giftcodesTable.$inferSelect;

export const giftcodeUsesTable = pgTable("giftcode_uses", {
  id: serial("id").primaryKey(),
  giftcode_id: integer("giftcode_id").notNull(),
  user_id: integer("user_id").notNull(),
  used_at: timestamp("used_at", { withTimezone: true }).notNull().defaultNow(),
});

export const fakeBotTable = pgTable("fake_bots", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  balance: bigint("balance", { mode: "number" }).notNull().default(1000000),
  min_bet: bigint("min_bet", { mode: "number" }).notNull().default(10000),
  max_bet: bigint("max_bet", { mode: "number" }).notNull().default(500000),
  bet_types: text("bet_types").notNull().default("tai,xiu"),
  delay_min: integer("delay_min").notNull().default(1),
  delay_max: integer("delay_max").notNull().default(5),
  balance_refill: bigint("balance_refill", { mode: "number" }).notNull().default(1000000),
  vip_icon: text("vip_icon").notNull().default("🏵️"),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertFakeBotSchema = createInsertSchema(fakeBotTable).omit({ id: true, created_at: true });
export type InsertFakeBot = z.infer<typeof insertFakeBotSchema>;
export type FakeBot = typeof fakeBotTable.$inferSelect;

export const gameSettingsTable = pgTable("game_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type GameSetting = typeof gameSettingsTable.$inferSelect;
